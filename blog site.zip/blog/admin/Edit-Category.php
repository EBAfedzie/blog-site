<?php
include 'partials/header.php';
?>

<section class="form_section">
    <div class="container form_section-container">
        <h2>Edit Catgory</h2>
        <form action="">
            <input type="text" placeholder="Title">
            <textarea rows="4" placeholder="Description"></textarea>
            <button type="submit" class="btns">Update Category</button>
        </form>
    </div>
</section>

<?php
include '../partials/footer.php';
?>