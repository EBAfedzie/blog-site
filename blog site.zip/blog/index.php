<?php
include 'partials/header.php'
?>




<!----------------- START FEARURED --------------->
<section class="featured">
    <div class="container featured_container">
        <div class="post_thumbnail">
            <img src="./images/science.jpg">
        </div>
        <div class="post_info">
            <a href="Science-Technology.php" class="category_button">Science & Technology</a>
            <h2 class="post_title"><a href="Post.html">What does a Lab Technician do?</a></h2>
            <p class="post_body">As a Lab Technician in pharma you provide wide-ranging support
                to the lab and its staff such as equipment maintenance and calibration, preparing
                samples and reagents, and carrying out experiments and tests to support complex scientific
                investigations. <a href=""> <i>Read More</i> </a>
            </p>
            <div class="post_author">
                <div class="post_author-avatar">
                    <img src="./images//avatar2.jpg">
                </div>
                <div class="post_author-info">
                    <h5>By: Manuel</h5>
                    <small>November 10, 07:00</small>
                </div>
            </div>
        </div>
    </div>
</section>
<!----------------- END FEARURED --------------->



<!----------------- START POSTS --------------->
<section class="posts">
    <div class="container posts_container">

        <article class="post">
            <div class="post_thumbnail">
                <img src="./images/blog24.jpg">
            </div>
            <div class="post_info">
                <a href="Business.php" class="category_button">Business</a>
                <h3 class="post_title">
                    <a href="Post.php">How does Bitcoin work?</a>
                </h3>
                <p class="post_body">You can get started with Bitcoin
                    without understanding the technical details. Once you've installed a
                    Bitcoin wallet on your computer or mobile phone, it will generate your
                    first Bitcoin address and you can create more
                    whenever you need one. <a href=""> <i>Read More</i> </a>
                </p>
                <div class="post_author">
                    <div class="post_author-avatar">
                        <img src="./images/avatar3.jpg" alt="">
                    </div>
                    <div class="post_author-info">
                        <h5>By: Afedzie</h5>
                        <small>October 13, 2023 - 10:30</small>
                    </div>
                </div>
            </div>
        </article>

        <article class="post">
            <div class="post_thumbnail">
                <img src="./images/graduation.jpg">
            </div>
            <div class="post_info">
                <a href="Education.php" class="category_button">Education</a>
                <h3 class="post_title">
                    <a href="Post.php">Check out KNUST 57TH Rehearsal and Colleges Congregation Dates.</a>
                </h3>
                <p class="post_body">Management of Kwame Nkrumah University of Science and Technology has
                    officially released the 57TH Rehearsal and Colleges
                    Congregation Dates. <a href=""> <i>Read More</i> </a>
                </p>
                <div class="post_author">
                    <div class="post_author-avatar">
                        <img src="./images/avatar4.jpg" alt="">
                    </div>
                    <div class="post_author-info">
                        <h5>By: Patoah</h5>
                        <small>October 9, 2023 - 14:05</small>
                    </div>
                </div>
            </div>
        </article>

        <article class="post">
            <div class="post_thumbnail">
                <img src="./images/grammy.jpg">
            </div>
            <div class="post_info">
                <a href="Entertainment.php" class="category_button">Entertainment</a>
                <h3 class="post_title">
                    <a href="Post.php">2024 GRAMMY Nominations: See The Full Nominees List.</a>
                </h3>
                <p class="post_body">The Recording Academy has officially revealed nominations
                    for the 2024 GRAMMYs, which will take place Sunday, Feb. 4, at
                    Crypto.com Arena in Los Angeles. <a href=""> <i>Read More</i> </a>
                </p>
                <div class="post_author">
                    <div class="post_author-avatar">
                        <img src="./images/avatar5.jpg" alt="">
                    </div>
                    <div class="post_author-info">
                        <h5>By: Ray</h5>
                        <small>September 22, 2023 - 18:03</small>
                    </div>
                </div>
            </div>
        </article>

        <article class="post">
            <div class="post_thumbnail">
                <img src="./images/blog15.jpg">
            </div>
            <div class="post_info">
                <a href="Science-Technology.php" class="category_button">Science & Technology</a>
                <h3 class="post_title">
                    <a href="Post.html">Man crushed to death by robot in South Korea</a>
                </h3>
                <p class="post_body">A man has been crushed to death by a robot in South Korea after
                    it failed to differentiate him from the boxes of food it
                    was handling, reports say. The incident occurred when the man, a robotics company
                    employee in his 40s, was inspecting the robot. <a href=""> <i>Read More</i> </a>
                </p>
                <div class="post_author">
                    <div class="post_author-avatar">
                        <img src="./images/avatar6.jpg" alt="">
                    </div>
                    <div class="post_author-info">
                        <h5>By: Esther</h5>
                        <small>Many 28, 2023 - 17:52</small>
                    </div>
                </div>
            </div>
        </article>

        <article class="post">
            <div class="post_thumbnail">
                <img src="./images/blog6.jpg">
            </div>
            <div class="post_info">
                <a href="Health.php" class="category_button">Health</a>
                <h3 class="post_title">
                    <a href="Post.php">12 most nutritious fruits.</a>
                </h3>
                <p class="post_body">Eating a range of healthful fruits provides the body with
                    nutrients and antioxidants that can boost overall health. Good choices
                    include oranges, blueberries, apples, avocados, and bananas, but there
                    are many more to choose from. <a href=""> <i>Read More</i> </a>
                </p>
                <div class="post_author">
                    <div class="post_author-avatar">
                        <img src="./images/avatar7.jpg" alt="">
                    </div>
                    <div class="post_author-info">
                        <h5>By: Gwendy</h5>
                        <small>July 3, 2023 - 06:11</small>
                    </div>
                </div>
            </div>
        </article>

        <article class="post">
            <div class="post_thumbnail">
                <img src="./images/pitch.jpg">
            </div>
            <div class="post_info">
                <a href="Sport.php" class="category_button">Sport</a>
                <h3 class="post_title">
                    <a href="Post.php">FIFA World Cup 2026: Full list of stadiums for the men's
                        event in Canada, Mexico, and the United States.
                    </a>
                </h3>
                <p class="post_body">The 23rd edition of the FIFA World Cup will take place across
                    Canada, Mexico, and the USA, including at Olympic venues. Here's the full list
                    of the 16 stadiums hosting the world’s biggest football event in 2026. <a href=""> <i>Read More</i> </a>
                </p>
                <div class="post_author">
                    <div class="post_author-avatar">
                        <img src="./images/avatar9.jpg" alt="">
                    </div>
                    <div class="post_author-info">
                        <h5>By: Manuel</h5>
                        <small>June 13, 2023 - 08:00</small>
                    </div>
                </div>
            </div>
        </article>
    </div>
</section>
<!-----------------END POSTS --------------->


<section class="category_buttons">
    <div class="container category_buttons-container">
        <a href="Science-Technology.php" class="category_button">Science & Technology</a>
        <a href="Business.php" class="category_button">Business</a>
        <a href="Sport.php" class="category_button">Sport</a>
        <a href="Education.php" class="category_button">Education</a>
        <a href="Health.php" class="category_button">Health</a>
        <a href="Entertainment.php" class="category_button">Entertainment</a>
    </div>
</section>
<!--============ END OF CATEGORY =============-->



<?php
include 'partials/footer.php'
?>