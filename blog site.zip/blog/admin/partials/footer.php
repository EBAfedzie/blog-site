<!--============ FOOTER =============-->
<footer>
    <div class="footer_socials">
        <a href="https://twitter.com/AqwesiManuel" target="_blank"><i class="uil uil-twitter"></i></a>
        <a href="https://instagram.com/AqwesiManuel" target="_blank"><i class="uil uil-instagram"></i></a>
        <a href="https://facebook.com/Äqwësi Ëmmä" target="_blank"><i class="uil uil-facebook-f"></i></a>
        <a href="https://t.me/AqwesiManuel" target="_blank"><i class="uil uil-telegram"></i></a>
        <a href="https://wa.me/0556209096" target="_blank"><i class="uil uil-whatsapp"></i></a>

    </div>
    <div class="container footer_container">
        <article>
            <h4>Categories</h4>
            <ul>
                <li><a href="Science-Technology.php">Science & Technology</a></li>
                <li><a href="Business.php">Business</a></li>
                <li><a href="Category-Post.php">Health</a></li>
                <li><a href="Entertainment.php">Entertainment</a></li>
                <li><a href="Education.php">Education</a></li>
                <li><a href="Sport.php">Sports</a></li>
            </ul>
        </article>

        <article>
            <h4> Support</h4>
            <ul>
                <li><a href="">Online Support</a></li>
                <li><a href="Contact.php">Call Numbers</a></li>
                <li><a href="Contact.php">Emails</a></li>
                <li><a href="">Social Support</a></li>
                <li><a href="Location.php">Location</a></li>
            </ul>
        </article>

        <article>
            <h4>Blog</h4>
            <ul>
                <li><a href="">Safety</a></li>
                <li><a href="">Repair</a></li>
                <li><a href="">Recent</a></li>
                <li><a href="">Popular</a></li>
                <li><a href="Category-Post.php">Categories</a></li>
            </ul>
        </article>

        <article>
            <h4>Permalinks</h4>
            <ul>
                <li><a href="Index.php">Home</a></li>
                <li><a href="Blog.php">Blog</a></li>
                <li><a href="About.php">About</a></li>
                <li><a href="Service.php">Service</a></li>
                <li><a href="Contact.php">Contact</a></li>
            </ul>
        </article>
    </div>

    <div class="footer_copyright">
        <small>copyright &copy; 2023 TECHTIDE</small>
    </div>
</footer>




<script src="<?= ROOT_URL ?>js/Main.js"></script>

</body>

</html>