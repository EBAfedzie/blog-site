<?php
include 'partials/header.php';
?>


<section class="dashboard">
    <div class="container dashboard_container">
        <button id="show_sidebar-btn" class="sidebar_toggle"><i class="uil uil-angle-right"></i></button>
        <button id="hide_sidebar-btn" class="sidebar_toggle"><i class="uil uil-angle-left"></i></button>
        <aside>
            <ul>
                <li><a href="Add-Post.php"><i class="uil uil-pen"></i>
                        <h5>Add Post</h5>
                    </a>
                </li>

                <li><a href="Index.php"><i class="uil uil-postcard"></i>
                        <h5>Manage Posts</h5>
                    </a>
                </li>
                <?php if(isset($_SESSION['user_is_admin'])) : ?>
                <li><a href="Add-User.php"><i class="uil uil-user-plus"></i>
                        <h5>Add User Post</h5>
                    </a>
                </li>

                <li><a href="Manage-User.php" class="active"><i class="uil uil-users-alt"></i>
                        <h5>Manage User</h5>
                    </a>
                </li>

                <li><a href="Add-Category.php"><i class="uil uil-edit"></i>
                        <h5>Add Category</h5>
                    </a>
                </li>

                <li><a href="Manage-Category.php"><i class="uil uil-list-ul"></i>
                        <h5>Manage Categories</h5>
                    </a>
                </li>
                <?php endif ?>
            </ul>
        </aside>


        <!--============ MAIN SECTION =============-->
        <main>
            <h2>Manage Users</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Edit</th>
                        <th>Delete</th>
                        <th>Admin</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Emmanuel Afedzie</td>
                        <td>Afedzie</td>
                        <td><a href="Edit-User.php" class="btns sm">Edit</a></td>
                        <td><a href="delete-category.php" class="btns sm danger">Delete</a></td>
                        <td>Yes</td>
                    </tr>
                    <tr>
                        <td>Patoah</td>
                        <td>Patoah</td>
                        <td><a href="Edit-User.php" class="btns sm">Edit</a></td>
                        <td><a href="delete-category.php" class="btns sm danger">Delete</a></td>
                        <td>No</td>
                    </tr>
                    <tr>
                        <td>Aqwesi Manuel</td>
                        <td>Manuel</td>
                        <td><a href="Edit-User.php" class="btns sm">Edit</a></td>
                        <td><a href="delete-category.php" class="btns sm danger">Delete</a></td>
                        <td>Yes</td>
                    </tr>
                </tbody>
            </table>
        </main>
    </div>
</section>

<?php
include '../partials/footer.php';
?>