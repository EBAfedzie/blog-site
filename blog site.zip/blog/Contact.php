<?php
    include 'partials/header.php';
?>



    <section class="empty_page">
        <h1>Contact Page</h1>
        <div class="alert_messages unavailable">
            <p>This page is empty</p>
        </div>
    </section>


    <?php
        include 'partials/footer.php';
    ?>