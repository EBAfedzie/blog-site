<?php
    include 'partials/header.php';
?>



    <!----------------- START CATEGORY TITLE --------------->
    <header class="category_title">
        <h2>Category Title</h2>
    </header>
    <!---=========== END OF CATEGORY TITLE ============-->




    <!----------------- START POSTS --------------->
    <section class="posts">
        <div class="container posts_container">

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog2.jpg">
                </div>
                <div class="post_info">
                    <a href="Category-Post.php" class="category_button">Science & Technology</a>
                    <h3 class="post_title">
                        <a href="Post.php">The United State of America is set to release over thousands of Robot </a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar3.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: RAY</h5>
                            <small>June 13, 2023 - 10:34AM</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog3.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">wild life</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar4.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog66.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Art</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar5.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog24.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Business</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar6.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog6.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Food</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar7.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/pitch.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Sports</a>
                    <h3 class="post_title">
                        <a href="Post.php">FIFA is considering playing the 2026 world cup final in Camp Nou or Santiago
                            Bernabeu</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar9.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/travel.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Travel</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar10.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog10.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Movies</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar11.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog45.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">wild life</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar12.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/movies2.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Movie</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar13.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/nice.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Travel</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar14.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/tech3.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Science & Technology</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar15.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/leo.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Sport</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar15.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog20.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Music</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar15.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/img4.jpg">
                </div>
                <div class="post_info">
                    <a href="" class="category_button">Food</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum, dolor sit amet consectetur
                            adipisicing elit. Laborum, dolore!</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar15.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

        </div>
    </section>
    <!-----------------END POSTS --------------->


    <section class="category_buttons">
        <div class="container category_buttons-container">
            <a href="Science-Technology.php" class="category_button">Science & Technology</a>
            <a href="Business.php" class="category_button">Business</a>
            <a href="Sport.php" class="category_button">Sports</a>
            <a href="Education.php" class="category_button">Education</a>
            <a href="Health.php" class="category_button">Health</a>
            <a href="Entertainment.php" class="category_button">Entertainment</a>
        </div>
    </section>
    <!--============ END OF CATEGORY =============-->



   <?php
    include 'partials/footer.php';
   ?>