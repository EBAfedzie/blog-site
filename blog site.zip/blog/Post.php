<?php
include 'partials/header.php';
?>

<section class="singlepost">
    <div class="container singlepost_container">
        <h2>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Iusto, omnis!</h2>
        <div class="post_author">
            <div class="post_author-avatar">
                <img src="./images//avatar2.jpg">
            </div>
            <div class="post_author-info">
                <h5>By: Manuel</h5>
                <small>November 10, 07:23AM</small>
            </div>
        </div>
        <div class="singlepost_thumbnail">
            <img src="./images/Messi3.jpeg">
        </div>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae suscipit
            officiis nisi fuga illo voluptates totam! Pariatur totam iusto quasi.
            Perspiciatis vero sit similique assumenda illo distinctio voluptates
            ipsa saepe veniam, commodi odit ut repellat nobis quae eveniet
            laudantium. Sed?</p>

        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae suscipit
            officiis nisi fuga illo voluptates totam! Pariatur totam iusto quasi.
            Perspiciatis vero sit similique assumenda illo distinctio voluptates
            ipsa saepe veniam, commodi odit ut repellat nobis quae eveniet
            laudantium. Sed?</p>

        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae suscipit
            officiis nisi fuga illo voluptates totam! Pariatur totam iusto quasi.
            Perspiciatis vero sit similique assumenda illo distinctio voluptates
            ipsa saepe veniam, commodi odit ut repellat nobis quae eveniet
            laudantium. Sed?</p>

        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quae suscipit
            officiis nisi fuga illo voluptates totam! Pariatur totam iusto quasi.
            Perspiciatis vero sit similique assumenda illo distinctio voluptates
            ipsa saepe veniam, commodi odit ut repellat nobis quae eveniet
            laudantium. Sed?</p>
    </div>
</section>



<?php
    include 'partials/footer.php'
?>