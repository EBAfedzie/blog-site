<?php
    include 'partials/header.php'
?>




    <!---=========== START SERCH BAR ============-->
    <section class="search_bar">
        <form class="container search_bar-container" action="">
            <div>
                <i class="uil uil-search"></i>
                <input type="search" name="" placeholder="search">
            </div>
            <button type="submit" class="btns">Go</button>
        </form>
    </section>
    <!---=========== START SERCH BAR ============-->




    <!----------------- START POSTS --------------->
    <section class="posts">
        <div class="container posts_container">

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog2.jpg">
                </div>
                <div class="post_info">
                    <a href="Science-Technology.php" class="category_button">Science & Technology</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar3.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: RAY</h5>
                            <small>June 13, 2023 - 10:34AM</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog101.jpg">
                </div>
                <div class="post_info">
                    <a href="Health.php" class="category_button">Health</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar4.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: John Mills</h5>
                            <small>June 13, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/B Ball.jpg">
                </div>
                <div class="post_info">
                    <a href="Sport.php" class="category_button">Sport</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar5.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Patoah</h5>
                            <small>May 11, 2023 - 10:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/Business.jpg">
                </div>
                <div class="post_info">
                    <a href="Education.php" class="category_button">Education</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar6.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Mr. Mathar Botwe</h5>
                            <small>September 13, 2023 - 21:14</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog10.jpg">
                </div>
                <div class="post_info">
                    <a href="Entertainment.php" class="category_button">Entertainment</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar7.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Essel</h5>
                            <small>June 28, 2023 - 00:00</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/pitch.jpg">
                </div>
                <div class="post_info">
                    <a href="Sport.php" class="category_button">Sport</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar9.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Randy</h5>
                            <small>August 3, 2023 - 09:30</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/speaker2.jpg">
                </div>
                <div class="post_info">
                    <a href="Business.php" class="category_button">Business</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar10.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Mr. David Forson</h5>
                            <small>February 8, 2023 - 20:00</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/movies2.jpg">
                </div>
                <div class="post_info">
                    <a href="Entertainment.php" class="category_button">Entertainment</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar11.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Sopha</h5>
                            <small>April 13, 2023 - 21:00</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/tech3.jpg">
                </div>
                <div class="post_info">
                    <a href="Science-Technology.php" class="category_button">Technology</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar12.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Aqwesi Manuel</h5>
                            <small>August, 2023 - 22:04</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/leo.jpg">
                </div>
                <div class="post_info">
                    <a href="Sport.php" class="category_button">Sport</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar13.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Evans</h5>
                            <small>March 13, 2022 - 19:52</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/nice.jpg">
                </div>
                <div class="post_info">
                    <a href="Entertainment.php" class="category_button">Entertainment</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar14.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Dominic</h5>
                            <small>June 22, 2023 - 18:54</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/img-5.jpg">
                </div>
                <div class="post_info">
                    <a href="Health.php" class="category_button">Health</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar15.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Ebenezer</h5>
                            <small>January 15, 2023 - 15:00</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/travel.jpg">
                </div>
                <div class="post_info">
                    <a href="Entertainment.php" class="category_button">Entertainment</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar15.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Stanley</h5>
                            <small>November 13, 2023 - 11:04</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/blog49.jpg">
                </div>
                <div class="post_info">
                    <a href="Entertainment.php" class="category_button">Entertainment</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar15.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Wisdom</h5>
                            <small>June 13, 2022 - 01:34</small>
                        </div>
                    </div>
                </div>
            </article>

            <article class="post">
                <div class="post_thumbnail">
                    <img src="./images/tech.jpg">
                </div>
                <div class="post_info">
                    <a href="Education.php" class="category_button">Education</a>
                    <h3 class="post_title">
                        <a href="Post.php">Lorem ipsum dolor sit amet consectetur.</a>
                    </h3>
                    <p class="post_body">Lorem ipsum dolor sit amet consectetur adipisicing
                        elit. Quaerat in ipsa quidem sed sit vel rem quis consequatur voluptatem praesentium!
                    </p>
                    <div class="post_author">
                        <div class="post_author-avatar">
                            <img src="./images/avatar15.jpg" alt="">
                        </div>
                        <div class="post_author-info">
                            <h5>By: Eric</h5>
                            <small>December 17, 2022 - 10:03</small>
                        </div>
                    </div>
                </div>
            </article>

        </div>
    </section>
    <!-----------------END POSTS --------------->


    <section class="category_buttons">
        <div class="container category_buttons-container">
            <a href="Science-Technology.php" class="category_button">Science & Technology</a>
            <a href="Business.php" class="category_button">Business</a>
            <a href="Sport.php" class="category_button">Sport</a>
            <a href="Education.php" class="category_button">Education</a>
            <a href="Health.php" class="category_button">Health</a>
            <a href="Entertainment.php" class="category_button">Entertainment</a>
        </div>
    </section>
    <!--============ END OF CATEGORY =============-->



    <?php
        include 'partials/footer.php'
    ?>